To run the demo, start the built-in Python HTTP server by

    python -m brython --server

The default port is 8080. To specify another port:

    python -m brython --server --port 8081

Then load http://localhost:<port>/demo.html in the browser address bar.

For more information please visit http://brython.info.